create definer = root@localhost view vuserinfo as
select `u`.`id`                                                       AS `id`,
       `u`.`loginNo`                                                  AS `loginNo`,
       `u`.`password`                                                 AS `password`,
       `u`.`userName`                                                 AS `userName`,
       `u`.`organId`                                                  AS `organId`,
       `u`.`sex`                                                      AS `sex`,
       `u`.`tel`                                                      AS `tel`,
       `u`.`status`                                                   AS `status`,
       (case when isnull(`n`.`name`) then '顶级区域' else `n`.`name` end) AS `organName`,
       (case when (`u`.`sex` = '1') then '男' else '女' end)            AS `sexName`,
       (case when (`u`.`status` = '1') then '注销' else '正常' end)       AS `statusInfo`
from (`ams`.`tbosuser` `u`
         left join `ams`.`tborgan` `n` on ((`u`.`organId` = `n`.`id`)));

