create definer = admin@`%` view vmodelinfo as
select `m`.`id`         AS `id`,
       `m`.`facId`      AS `facId`,
       `m`.`model`      AS `model`,
       `m`.`remark`     AS `remark`,
       `m`.`updateTime` AS `updateTime`,
       `f`.`name`       AS `name`,
       `f`.`shortName`  AS `shortName`
from (`ams`.`tbmodel` `m`
         left join `ams`.`tbfacturer` `f` on ((`m`.`facId` = `f`.`facId`)));

