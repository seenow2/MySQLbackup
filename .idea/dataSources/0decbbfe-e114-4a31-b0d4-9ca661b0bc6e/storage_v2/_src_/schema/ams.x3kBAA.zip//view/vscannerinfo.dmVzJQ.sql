create definer = admin@`%` view vscannerinfo as
select `s`.`id`         AS `id`,
       `s`.`organId`    AS `organId`,
       `s`.`facId`      AS `facId`,
       `s`.`model`      AS `model`,
       `s`.`serialNo`   AS `serialNo`,
       `s`.`remark`     AS `remark`,
       `s`.`updateTime` AS `updateTime`,
       `f`.`name`       AS `fname`,
       `f`.`shortName`  AS `fshortname`,
       `o`.`name`       AS `oname`,
       `o`.`shortName`  AS `oshortname`
from ((`ams`.`tbscanner` `s` left join `ams`.`tbfacturer` `f` on ((`s`.`facId` = `f`.`facId`)))
         left join `ams`.`tborgan` `o` on ((`s`.`organId` = `o`.`id`)));

