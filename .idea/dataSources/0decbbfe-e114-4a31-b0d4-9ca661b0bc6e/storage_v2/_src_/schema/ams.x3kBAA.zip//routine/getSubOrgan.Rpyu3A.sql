create
    definer = root@localhost function getSubOrgan(organId int) returns varchar(1000)
BEGIN
   DECLARE sTemp VARCHAR(1000);
   DECLARE sTempChd VARCHAR(1000);

   SET sTemp = '$';
   SET sTempChd =cast(organId as CHAR);
   WHILE sTempChd is not null DO 
		 SET sTemp = concat(sTemp,',',sTempChd);
     SELECT group_concat(id) INTO sTempChd FROM tborgan where FIND_IN_SET(parentId,sTempChd)>0;
		
   END WHILE;
   RETURN sTemp;
 END;

